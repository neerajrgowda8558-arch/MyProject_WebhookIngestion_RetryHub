import os
import pygame

from .paddle import Paddle
from .ball import Ball
from .brick import Brick

# Game Engine

WHITE = (255, 255, 255)
BG = (15, 15, 25)

BRICK_COLORS = [
    (200, 60, 60),
    (200, 140, 60),
    (200, 200, 60),
    (80, 180, 80),
    (80, 140, 200),
]

# Ball speed multipliers.
DIFFICULTIES = {
    "Easy": 0.70,
    "Medium": 1.00,
    "Hard": 1.50,
}

# Sound filenames inside assets/sounds/.
SOUND_FILES = {
    "brick": "brick_hit.wav",
    "paddle": "paddle_hit.wav",
    "wall": "wall_hit.wav",
    "win": "win.wav",
    "game_over": "game_over.wav",
}


class GameEngine:
    def __init__(self, width, height):
        self.width = width
        self.height = height

        self.rows, self.cols = 5, 8

        # Difficulty settings.
        self.difficulty = "Medium"
        self.base_speed = 4

        self.paddle = Paddle(
            width // 2 - 50,
            height - 30,
            100,
            14,
        )

        self.ball = Ball(
            width // 2,
            height - 50,
            radius=8,
        )
        self._set_ball_speed()

        self.bricks = self._build_bricks(
            self.rows, self.cols
        )

        self.lives = 3
        self.score = 0
        self.game_over = False
        self.result = None

        # Fonts.
        self.font = pygame.font.SysFont("Arial", 28)
        self.end_title_font = pygame.font.SysFont(
            "Arial", 56, bold=True
        )
        self.end_score_font = pygame.font.SysFont(
            "Arial", 38, bold=True
        )
        self.end_instruction_font = pygame.font.SysFont(
            "Arial", 22
        )
        self.end_option_font = pygame.font.SysFont(
            "Arial", 25, bold=True
        )

        # Load sounds without making audio a requirement
        # for the game to run.
        self.sounds = self._load_sounds()

    # ------------------------------------------------------
    # Sound handling
    # ------------------------------------------------------

    def _load_sounds(self):
        """Load available sound effects; missing files are ignored."""
        sounds = {
            name: None for name in SOUND_FILES
        }

        try:
            # Initialize the mixer if main.py has not done so.
            if pygame.mixer.get_init() is None:
                pygame.mixer.init()
        except (pygame.error, OSError):
            # Audio hardware or mixer may be unavailable.
            return sounds

        # game_engine.py is inside game/, so go up one
        # directory to find the project root.
        project_root = os.path.dirname(
            os.path.dirname(os.path.abspath(__file__))
        )

        sound_dir = os.path.join(
            project_root, "assets", "sounds"
        )

        for name, filename in SOUND_FILES.items():
            path = os.path.join(sound_dir, filename)

            if not os.path.isfile(path):
                continue

            try:
                sounds[name] = pygame.mixer.Sound(path)
            except (pygame.error, OSError):
                # Ignore corrupt or unsupported sound files.
                sounds[name] = None

        return sounds

    def _play_sound(self, name):
        """Play a loaded sound safely."""
        sound = self.sounds.get(name)

        if sound is None:
            return

        try:
            sound.play()
        except (pygame.error, OSError):
            # Sound playback must never interrupt gameplay.
            pass

    def _finish_game(self, result):
        """Finish a round and play its end sound exactly once."""
        if self.game_over:
            return

        self.game_over = True
        self.result = result

        if result == "win":
            self._play_sound("win")
        else:
            self._play_sound("game_over")

    # ------------------------------------------------------
    # Game setup
    # ------------------------------------------------------

    def _build_bricks(self, rows, cols):
        bricks = []
        margin, gap, top = 30, 6, 60

        brick_w = (
            self.width - margin * 2 - gap * (cols - 1)
        ) // cols
        brick_h = 22

        for r in range(rows):
            for c in range(cols):
                x = margin + c * (brick_w + gap)
                y = top + r * (brick_h + gap)

                bricks.append(
                    Brick(x, y, brick_w, brick_h)
                )

        return bricks

    def _set_ball_speed(self):
        speed = (
            self.base_speed
            * DIFFICULTIES[self.difficulty]
        )

        self.ball.vx = speed
        self.ball.vy = -speed

    # ------------------------------------------------------
    # Input handling
    # ------------------------------------------------------

    def handle_event(self, event):
        if not self.game_over:
            return

        if event.type != pygame.KEYDOWN:
            return

        if event.key == pygame.K_ESCAPE:
            pygame.quit()
            raise SystemExit

        # Select the difficulty for the next round.
        if event.key == pygame.K_1:
            self.difficulty = "Easy"

        elif event.key == pygame.K_2:
            self.difficulty = "Medium"

        elif event.key == pygame.K_3:
            self.difficulty = "Hard"

        # Restart the game using the selected difficulty.
        elif event.key in (
            pygame.K_r,
            pygame.K_RETURN,
        ):
            self.restart()

    def handle_input(self):
        if self.game_over:
            return

        keys = pygame.key.get_pressed()

        if keys[pygame.K_LEFT] or keys[pygame.K_a]:
            self.paddle.move(
                -self.paddle.speed, self.width
            )

        if keys[pygame.K_RIGHT] or keys[pygame.K_d]:
            self.paddle.move(
                self.paddle.speed, self.width
            )

    # ------------------------------------------------------
    # Game update and collision detection
    # ------------------------------------------------------

    def update(self):
        if self.game_over:
            return

        previous_x = self.ball.x
        previous_y = self.ball.y

        self.ball.move()

        # Wall collisions.
        wall_hit = False

        if self.ball.x - self.ball.radius <= 0:
            self.ball.x = self.ball.radius

            if self.ball.vx < 0:
                self.ball.vx *= -1
                wall_hit = True

        elif self.ball.x + self.ball.radius >= self.width:
            self.ball.x = self.width - self.ball.radius

            if self.ball.vx > 0:
                self.ball.vx *= -1
                wall_hit = True

        if self.ball.y - self.ball.radius <= 0:
            self.ball.y = self.ball.radius

            if self.ball.vy < 0:
                self.ball.vy *= -1
                wall_hit = True

        # Play once if at least one wall reflection occurred.
        if wall_hit:
            self._play_sound("wall")

        # Paddle collision.
        ball_rect = self.ball.rect()
        paddle_rect = self.paddle.rect()

        if (
            ball_rect.colliderect(paddle_rect)
            and self.ball.vy > 0
        ):
            self.ball.y = (
                paddle_rect.top - self.ball.radius
            )
            self.ball.vy = -abs(self.ball.vy)

            # Change the bounce angle based on where the
            # ball hits the paddle.
            hit_offset = (
                self.ball.x - paddle_rect.centerx
            ) / (paddle_rect.width / 2)

            hit_offset = max(
                -1.0, min(1.0, hit_offset)
            )

            speed_x = max(1, abs(self.ball.vx))
            self.ball.vx = hit_offset * speed_x

            if abs(self.ball.vx) < 1:
                self.ball.vx = (
                    1 if hit_offset >= 0 else -1
                )

            self._play_sound("paddle")

        # Brick collision.
        # Only one brick can be destroyed per update.
        for brick in self.bricks:
            if not brick.alive:
                continue

            brick_rect = brick.rect()
            ball_rect = self.ball.rect()

            if not ball_rect.colliderect(brick_rect):
                continue

            previous_left = (
                previous_x - self.ball.radius
            )
            previous_right = (
                previous_x + self.ball.radius
            )
            previous_top = (
                previous_y - self.ball.radius
            )
            previous_bottom = (
                previous_y + self.ball.radius
            )

            hit_from_top = (
                previous_bottom <= brick_rect.top
                and self.ball.vy > 0
            )

            hit_from_bottom = (
                previous_top >= brick_rect.bottom
                and self.ball.vy < 0
            )

            hit_from_left = (
                previous_right <= brick_rect.left
                and self.ball.vx > 0
            )

            hit_from_right = (
                previous_left >= brick_rect.right
                and self.ball.vx < 0
            )

            if hit_from_top:
                self.ball.y = (
                    brick_rect.top - self.ball.radius
                )
                self.ball.vy = -abs(self.ball.vy)

            elif hit_from_bottom:
                self.ball.y = (
                    brick_rect.bottom + self.ball.radius
                )
                self.ball.vy = abs(self.ball.vy)

            elif hit_from_left:
                self.ball.x = (
                    brick_rect.left - self.ball.radius
                )
                self.ball.vx = -abs(self.ball.vx)

            elif hit_from_right:
                self.ball.x = (
                    brick_rect.right + self.ball.radius
                )
                self.ball.vx = abs(self.ball.vx)

            else:
                # Resolve corner or ambiguous collisions
                # using the smallest overlap.
                overlap_left = (
                    ball_rect.right - brick_rect.left
                )
                overlap_right = (
                    brick_rect.right - ball_rect.left
                )
                overlap_top = (
                    ball_rect.bottom - brick_rect.top
                )
                overlap_bottom = (
                    brick_rect.bottom - ball_rect.top
                )

                min_x_overlap = min(
                    overlap_left, overlap_right
                )
                min_y_overlap = min(
                    overlap_top, overlap_bottom
                )

                if min_x_overlap < min_y_overlap:
                    if overlap_left < overlap_right:
                        self.ball.x = (
                            brick_rect.left
                            - self.ball.radius
                        )
                    else:
                        self.ball.x = (
                            brick_rect.right
                            + self.ball.radius
                        )

                    self.ball.vx *= -1

                else:
                    if overlap_top < overlap_bottom:
                        self.ball.y = (
                            brick_rect.top
                            - self.ball.radius
                        )
                    else:
                        self.ball.y = (
                            brick_rect.bottom
                            + self.ball.radius
                        )

                    self.ball.vy *= -1

            brick.alive = False
            self.score += 1

            # Sound only when a living brick is destroyed.
            self._play_sound("brick")

            break

        # Lose a life if the ball falls below the screen.
        if self.ball.y - self.ball.radius > self.height:
            self.lives -= 1

            if self.lives <= 0:
                self._finish_game("lose")
            else:
                self._reset_ball()

        # Win when all bricks have been destroyed.
        if (
            not self.game_over
            and all(not brick.alive for brick in self.bricks)
        ):
            self._finish_game("win")

    # ------------------------------------------------------
    # Reset and replay
    # ------------------------------------------------------

    def _reset_ball(self):
        self.ball.x = self.width // 2
        self.ball.y = self.height - 50
        self._set_ball_speed()

    def restart(self):
        # Reset paddle position.
        self.paddle = Paddle(
            self.width // 2 - 50,
            self.height - 30,
            100,
            14,
        )

        # Reset ball position and selected speed.
        self.ball = Ball(
            self.width // 2,
            self.height - 50,
            radius=8,
        )
        self._set_ball_speed()

        # Restore every brick.
        self.bricks = self._build_bricks(
            self.rows, self.cols
        )

        # Reset round state.
        self.score = 0
        self.lives = 3
        self.game_over = False
        self.result = None

    # ------------------------------------------------------
    # Rendering
    # ------------------------------------------------------

    def render(self, screen):
        screen.fill(BG)

        if self.game_over:
            self._render_end_screen(screen)
            return

        pygame.draw.rect(
            screen, WHITE, self.paddle.rect()
        )

        pygame.draw.circle(
            screen,
            WHITE,
            (int(self.ball.x), int(self.ball.y)),
            self.ball.radius,
        )

        for i, brick in enumerate(self.bricks):
            if brick.alive:
                row = i // self.cols
                color = BRICK_COLORS[
                    row % len(BRICK_COLORS)
                ]
                pygame.draw.rect(
                    screen, color, brick.rect()
                )

        score_text = self.font.render(
            f"Score: {self.score}", True, WHITE
        )
        screen.blit(score_text, (10, 10))

        lives_text = self.font.render(
            f"Lives: {self.lives}", True, WHITE
        )
        screen.blit(
            lives_text,
            (self.width - 130, 10),
        )

    def _render_end_screen(self, screen):
        screen.fill(BG)

        if self.result == "win":
            title = "YOU WIN!"
            title_color = (80, 220, 120)
        else:
            title = "GAME OVER!"
            title_color = (240, 90, 90)

        title_surface = self.end_title_font.render(
            title, True, title_color
        )
        score_surface = self.end_score_font.render(
            f"Final Score: {self.score}", True, WHITE
        )
        lives_surface = self.font.render(
            f"Lives Remaining: {self.lives}",
            True,
            WHITE,
        )

        title_rect = title_surface.get_rect(
            center=(
                self.width // 2,
                self.height // 2 - 145,
            )
        )
        score_rect = score_surface.get_rect(
            center=(
                self.width // 2,
                self.height // 2 - 80,
            )
        )
        lives_rect = lives_surface.get_rect(
            center=(
                self.width // 2,
                self.height // 2 - 35,
            )
        )

        screen.blit(title_surface, title_rect)
        screen.blit(score_surface, score_rect)
        screen.blit(lives_surface, lives_rect)

        # Difficulty selection.
        difficulty_surface = (
            self.end_instruction_font.render(
                "Select Difficulty:",
                True,
                WHITE,
            )
        )
        difficulty_rect = difficulty_surface.get_rect(
            center=(
                self.width // 2,
                self.height // 2 + 10,
            )
        )
        screen.blit(difficulty_surface, difficulty_rect)

        option_y = self.height // 2 + 48
        option_gap = self.width // 3

        options = [
            ("1  EASY", "Easy"),
            ("2  MEDIUM", "Medium"),
            ("3  HARD", "Hard"),
        ]

        for index, (label, difficulty) in enumerate(options):
            selected = self.difficulty == difficulty

            color = (
                (100, 230, 130)
                if selected
                else WHITE
            )

            if selected:
                label = f"> {label} <"

            surface = self.end_option_font.render(
                label, True, color
            )
            rect = surface.get_rect(
                center=(
                    int(option_gap * (index + 0.5)),
                    option_y,
                )
            )
            screen.blit(surface, rect)

        selected_surface = (
            self.end_instruction_font.render(
                f"Selected: {self.difficulty}",
                True,
                (100, 200, 255),
            )
        )
        selected_rect = selected_surface.get_rect(
            center=(
                self.width // 2,
                self.height // 2 + 88,
            )
        )
        screen.blit(selected_surface, selected_rect)

        restart_surface = self.end_option_font.render(
            "Press R or ENTER to play again",
            True,
            WHITE,
        )
        restart_rect = restart_surface.get_rect(
            center=(
                self.width // 2,
                self.height // 2 + 132,
            )
        )
        screen.blit(restart_surface, restart_rect)

        exit_surface = self.end_instruction_font.render(
            "Press ESC to exit",
            True,
            WHITE,
        )
        exit_rect = exit_surface.get_rect(
            center=(
                self.width // 2,
                self.height // 2 + 170,
            )
        )
        screen.blit(exit_surface, exit_rect)
